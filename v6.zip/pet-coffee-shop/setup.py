# Brewskers — database setup.
# Run this once for a new installation.
# This script deletes the existing database before recreating it.

import os
import sqlite3

from werkzeug.security import generate_password_hash


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_PATH = os.environ.get(
    "DATABASE_PATH",
    os.path.join(BASE_DIR, "petcoffeeshop.db"),
)


def setup():
    if os.path.exists(DATABASE_PATH):
        os.remove(DATABASE_PATH)

    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("PRAGMA foreign_keys = ON")

    cursor.executescript(
        """
        CREATE TABLE users (
            user_id              INTEGER PRIMARY KEY AUTOINCREMENT,
            username             TEXT NOT NULL UNIQUE,
            email                TEXT NOT NULL UNIQUE,
            password             TEXT NOT NULL,
            role                 TEXT NOT NULL DEFAULT 'staff',
            must_change_password INTEGER NOT NULL DEFAULT 0,
            deactivated_at       DATETIME DEFAULT NULL,
            created_by           INTEGER REFERENCES users(user_id),
            created_at           DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_login_at        DATETIME DEFAULT NULL
        );

        CREATE TABLE sessions (
            session_id  INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            token       TEXT    NOT NULL UNIQUE,
            expires_at  DATETIME NOT NULL
        );

        CREATE TABLE remember_tokens (
            token_id   INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            token      TEXT    NOT NULL UNIQUE,
            expires_at DATETIME NOT NULL
        );

        CREATE TABLE otps (
            otp_id     INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
            otp_code   TEXT    NOT NULL,
            purpose    TEXT    NOT NULL,
            expires_at DATETIME NOT NULL,
            used_at    DATETIME DEFAULT NULL
        );

        CREATE TABLE store_profile (
            store_id   INTEGER PRIMARY KEY AUTOINCREMENT,
            store_name TEXT NOT NULL,
            address    TEXT,
            phone      TEXT,
            email      TEXT
        );

        CREATE TABLE products (
            product_id INTEGER PRIMARY KEY AUTOINCREMENT,
            category   TEXT NOT NULL,
            name       TEXT NOT NULL,
            price      REAL NOT NULL,
            stock      INTEGER NOT NULL DEFAULT 0,
            emoji      TEXT DEFAULT '☕',
            status     TEXT DEFAULT 'available'
        );

        CREATE TABLE orders (
            order_id       INTEGER PRIMARY KEY AUTOINCREMENT,
            order_no       TEXT NOT NULL UNIQUE,
            customer_name  TEXT,
            total_amount   REAL NOT NULL,
            payment_method TEXT DEFAULT 'cash',
            amount_paid    REAL,
            change_amount  REAL,
            order_date     DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_by     INTEGER REFERENCES users(user_id)
        );

        CREATE TABLE order_items (
            item_id     INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id    INTEGER NOT NULL REFERENCES orders(order_id),
            product_id  INTEGER NOT NULL REFERENCES products(product_id),
            quantity    INTEGER NOT NULL,
            price       REAL NOT NULL
        );

        CREATE TABLE services (
            service_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name       TEXT NOT NULL,
            price      REAL NOT NULL,
            duration   INTEGER DEFAULT 30,
            active     INTEGER NOT NULL DEFAULT 1
        );

        CREATE TABLE appointments (
            appointment_id INTEGER PRIMARY KEY AUTOINCREMENT,
            pet_name   TEXT NOT NULL,
            pet_type   TEXT DEFAULT 'Dog',
            breed      TEXT,
            pet_age    TEXT,
            owner_name TEXT NOT NULL,
            phone      TEXT NOT NULL,
            service_id INTEGER NOT NULL REFERENCES services(service_id),
            appt_date  DATE NOT NULL,
            appt_time  TIME NOT NULL,
            status     TEXT DEFAULT 'scheduled',
            notes      TEXT,
            photo      TEXT,
            created_by INTEGER REFERENCES users(user_id),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        """
    )

    cursor.execute(
        "INSERT INTO store_profile "
        "(store_name, address, phone, email) "
        "VALUES (?, ?, ?, ?)",
        (
            "Brewskers",
            "123 Sample St",
            "0900-000-0000",
            "hello@brewskers.example",
        ),
    )

    cursor.execute(
        "INSERT INTO users "
        "(username, email, password, role, must_change_password) "
        "VALUES (?, ?, ?, 'admin', 0)",
        (
            "admin",
            "admin@brewskers.test",
            generate_password_hash("12345678"),
        ),
    )

    menu = [
        ("Coffee", "Espresso", 90, 25, "☕"),
        ("Coffee", "Americano", 100, 30, "☕"),
        ("Coffee", "Cappuccino", 120, 20, "🥛"),
        ("Coffee", "Cafe Latte", 130, 25, "☕"),
        ("Coffee", "Caramel Macchiato", 150, 18, "☕"),
        ("Coffee", "Mocha", 140, 20, "🍫"),
        ("Coffee", "Vanilla Latte", 145, 15, "🥤"),
        ("Coffee", "Spanish Latte", 150, 20, "☕"),
        ("Coffee", "Matcha Latte", 145, 15, "🍵"),
        ("Coffee", "Cold Brew", 135, 18, "🧊"),
    # Pastries
        ("Pastry", "Butter Croissant", 85, 15, "🥐"),
        ("Pastry", "Chocolate Croissant", 100, 12, "🥐"),
        ("Pastry", "Blueberry Muffin", 75, 20, "🧁"),
        ("Pastry", "Chocolate Muffin", 75, 18, "🧁"),
        ("Pastry", "Cinnamon Roll", 95, 15, "🍥"),
        ("Pastry", "Blueberry Cheesecake", 150, 10, "🍰"),
        ("Pastry", "Chocolate Brownie", 80, 20, "🍫"),
        ("Pastry", "Strawberry Danish", 100, 12, "🍓"),
        ("Pastry", "Glazed Donut", 65, 20, "🍩"),
        ("Pastry", "Banana Bread", 85, 15, "🍞"),
        # Pet Treats
        ("Pet Treat", "Dog Biscuits", 80, 25, "🦴"),
        ("Pet Treat", "Chicken Jerky Bites (Dog)", 120, 15, "🐶"),
        ("Pet Treat", "Beef Training Bites (Dog)", 100, 20, "🦴"),
        ("Pet Treat", "Salmon Dog Treats", 130, 12, "🐟"),
        ("Pet Treat", "Dental Chews (Dog)", 110, 18, "🦷"),
        ("Pet Treat", "Tuna Cat Treats", 90, 20, "🐱"),
        ("Pet Treat", "Salmon Cat Sticks", 100, 15, "🐟"),
        ("Pet Treat", "Chicken Cat Bites", 95, 20, "🐔"),
        ("Pet Treat", "Catnip Crunchies", 85, 18, "🌿"),
        ("Pet Treat", "Freeze-Dried Chicken (Cat)", 140, 10, "🍗")
    ]

    cursor.executemany(
        "INSERT INTO products "
        "(category, name, price, stock, emoji) "
        "VALUES (?, ?, ?, ?, ?)",
        menu,
    )

    services = [
        ("Bath & Brush", 350, 45),
        ("Full Groom", 850, 90),
        ("Nail Trim", 150, 15),
        ("Teeth Brushing", 200, 20),
        ("Vet Checkup", 500, 30),
        ("Vaccination", 450, 20),
        ("Flea Treatment", 400, 30),
        ("Pet Spa Package", 1500, 120),
    ]

    cursor.executemany(
        "INSERT INTO services (name, price, duration) "
        "VALUES (?, ?, ?)",
        services,
    )

    conn.commit()
    conn.close()

    print("Brewskers database ready.")
    print("Login: admin / 12345678")


if __name__ == "__main__":
    setup()