const $ = (selector) => document.querySelector(selector);

// Escape text before putting it into innerHTML (prevents XSS).
const esc = (value) =>
  String(value ?? "").replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
  );

const csrfToken = () =>
  document.querySelector('meta[name="csrf-token"]')?.content || "";

const peso = (amount) =>
  "₱" +
  Number(amount).toLocaleString("en-PH", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

function toast(text, type = "success") {
  const element = $("#toast");

  if (!element) return;

  element.innerHTML =
    '<span class="toast-ic">' +
    (type === "error" ? "!" : type === "info" ? "i" : "✓") +
    '</span><span class="toast-text"></span>';

  element.querySelector(".toast-text").textContent = text;
  element.className = `toast ${type} show`;

  clearTimeout(toast.timer);

  toast.timer = setTimeout(
    () => element.classList.remove("show"),
    type === "error" ? 4000 : 2500
  );
}

async function api(path, body = {}, method = "POST") {
  const response = await fetch(path, {
    method,
    headers: {
      "Content-Type": "application/json",
      "X-CSRF-Token": csrfToken()
    },
    body: JSON.stringify(body || {})
  });

  if (response.status === 401) {
    location.href = "/";

    return {
      ok: false,
      error: "Please log in"
    };
  }

  let result;

  try {
    result = await response.json();
  } catch (err) {
    return { ok: false, error: "Server error. Please try again." };
  }

  if (!response.ok && result.ok === undefined) {
    result.ok = false;
    result.error =
      result.error || "The request could not be completed.";
  }

  return result;
}

const openModal = () => $("#modal")?.classList.add("open");
const closeModal = () => $("#modal")?.classList.remove("open");

async function submitForm(event, path) {
  event.preventDefault();

  const result = await api(
    path,
    Object.fromEntries(new FormData(event.target))
  );

  if (result.ok) {
    location.reload();
  } else {
    toast(result.error || "Could not save", "error");
  }
}

async function setStatus(id, status) {
  const result = await api(
    `/api/appointments/${id}/status`,
    { status }
  );

  if (result.ok) {
    location.reload();
  } else {
    toast(result.error || "Could not update appointment", "error");
  }
}